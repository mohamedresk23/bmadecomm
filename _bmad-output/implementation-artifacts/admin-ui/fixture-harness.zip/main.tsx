import React from 'react';
import { createRoot } from 'react-dom/client';
import { usePathname } from './next';
import { AdminShell } from '../../src/app/admin/(workspace)/admin-shell';
import { AdminPageHeader } from '../../src/app/admin/(workspace)/admin-page-header';
import { ProductManager } from '../../src/app/admin/(workspace)/catalog/products/product-manager';
import { CategoryManager } from '../../src/app/admin/(workspace)/catalog/categories/category-manager';
import { StoreProfileForm } from '../../src/app/admin/(workspace)/settings/profile-form';
import { ShippingSettingsManager } from '../../src/app/admin/(workspace)/settings/shipping-manager';
import { StaffAccessForm } from '../../src/app/admin/staff-access-form';
import { staffNavigation } from '../../src/modules/identity/application/staff-navigation';
import '../../src/app/globals.css';
import '../../src/app/admin/(workspace)/admin.css';
function App() {
  const pathname = usePathname();
  const roles = new URLSearchParams(location.search).get('role') ?? 'owner';
  const shipping = new URLSearchParams(location.search).get('tab') === 'shipping';
  const title = pathname.includes('products') ? 'مسودات المنتجات' : pathname.includes('categories') ? 'تصنيفات المنتجات' : pathname.includes('settings') ? 'إعدادات المتجر' : pathname.includes('security') ? 'أمان الحساب' : 'لوحة الإدارة';
  return <AdminShell items={staffNavigation([roles])}><AdminPageHeader title={title} description="إدارة بيانات المتجر وتنظيم العمل بسهولة." section={pathname.includes('/catalog/') ? 'الكتالوج' : undefined} />
    {pathname.includes('products') ? <ProductManager /> : pathname.includes('categories') ? <CategoryManager /> : pathname.includes('settings') ? shipping ? <ShippingSettingsManager /> : <StoreProfileForm /> : pathname.includes('security') ? <StaffAccessForm initialMode="security" /> : <div className="rounded-2xl border border-slate-300 bg-white p-6"><h2>مرحبًا بك في لوحة الإدارة</h2><p>اختر القسم المناسب من القائمة الجانبية.</p></div>}
  </AdminShell>;
}
createRoot(document.getElementById('root')!).render(<App />);
