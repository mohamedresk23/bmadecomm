import { createServer } from 'vite';
import path from 'node:path';
const server = await createServer({ configFile: false, root: process.cwd(), server: { host: '127.0.0.1', port: 4173, strictPort: true }, resolve: { alias: { 'next/link': path.resolve('.local/admin-ui/next.tsx'), 'next/navigation': path.resolve('.local/admin-ui/next.tsx') } }, esbuild: { jsx: 'automatic' } });
await server.listen();
console.log('Admin UI fixture server: http://127.0.0.1:4173/.local/admin-ui/index.html');
