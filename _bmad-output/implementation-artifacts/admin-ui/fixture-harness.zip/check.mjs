import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright-core';
import { csrf, profile, category, zone, product } from './fixtures.mjs';

const directory = '_bmad-output/implementation-artifacts/admin-ui';
await mkdir(directory, { recursive: true });
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const errors = [], checks = [], mutations = [];
page.on('pageerror', error => errors.push(error.message));
let products = [product({ name: 'قميص قطني بألوان متعددة', description: 'منتج تجريبي لعرض واجهة الإدارة', categoryIds: [category.id], variants: [{ sku: 'UI-SHIRT', priceMinor: '29900', comparePriceMinor: null, attributes: {} }] })];
let categories = [category];
let failed = '';
await page.route('**/api/**', async route => {
  const request = route.request(), url = new URL(request.url());
  if (!url.pathname.startsWith('/api/')) { await route.continue(); return; }
  const method = request.method();
  let body;
  if (method !== 'GET') { body = request.postDataJSON(); mutations.push({ path: url.pathname, method, body, headers: request.headers() }); }
  let response = {};
  if (failed && url.pathname.includes(failed)) { await route.fulfill({ status: 500, json: { error: { code: 'TEST_FAILURE', message: 'فشل تجريبي في تحميل البيانات' } } }); return; }
  if (url.pathname.includes('/catalog/products')) {
    if (method === 'GET') response = url.pathname.endsWith('/products') ? { products, csrf, metadata: { currency: 'EGP', currencyScale: 2, pricingRevision: 'EGP:2', categories: categories.map(({ id, name }) => ({ id, name })) } } : { product: products[0], csrf };
    else { const saved = product(body); products = [saved]; response = { product: saved }; }
  } else if (url.pathname.includes('/catalog/categories')) {
    if (method !== 'GET') categories = [{ ...category, ...body, id: 'cat-added', children: [] }];
    response = { categories, csrf };
  } else if (url.pathname.includes('/settings/profile')) response = { profile: method === 'PUT' ? { ...profile, ...body } : profile, csrf, currency_locked: false, currency_locked_reason: null };
  else if (url.pathname.includes('/settings/shipping')) response = { zones: [zone], csrf };
  else if (url.pathname.includes('/auth/session')) response = { csrf };
  else response = { csrf };
  await route.fulfill({ status: 200, json: response });
});
async function go(path) {
  await page.goto('http://127.0.0.1:4173/.local/admin-ui/index.html', { waitUntil: 'networkidle' });
  await page.evaluate(path => { history.replaceState(null, '', path); window.dispatchEvent(new PopStateEvent('popstate')); }, path);
  await page.getByRole('heading', { level: 1 }).waitFor();
}
async function overflow(label) {
  const sizes = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, width: window.innerWidth, direction: getComputedStyle(document.documentElement).direction }));
  assert.equal(sizes.direction, 'rtl'); assert.ok(sizes.scroll <= sizes.width + 1, `${label}: document overflow ${JSON.stringify(sizes)}`); checks.push(`${label}: RTL, no document overflow`);
}
try {
  await go('/admin/catalog/products');
  await page.getByRole('button', { name: 'تعديل قميص قطني بألوان متعددة' }).waitFor();
  await overflow('Desktop products');
  await page.screenshot({ path: `${directory}/desktop.png`, fullPage: true });
  await page.getByRole('button', { name: 'طي القائمة', exact: true }).click();
  assert.equal(await page.getByRole('button', { name: 'توسيع القائمة', exact: true }).getAttribute('aria-expanded'), 'false');
  await page.getByRole('link', { name: 'المنتجات', exact: true }).focus();
  assert.equal(await page.getByRole('link', { name: 'المنتجات', exact: true }).getAttribute('aria-current'), 'page');
  await page.getByRole('button', { name: 'توسيع القائمة', exact: true }).click();
  await page.getByRole('link', { name: 'التصنيفات', exact: true }).click();
  await page.getByRole('button', { name: /إضافة تصنيف رئيسي/ }).waitFor();
  assert.equal(await page.getByRole('link', { name: 'التصنيفات', exact: true }).getAttribute('aria-current'), 'page');
  checks.push('Desktop collapse/expand, keyboard focus and navigation/active state');
  await go('/admin/catalog/products/child');
  assert.equal(await page.getByRole('link', { name: 'المنتجات', exact: true }).getAttribute('aria-current'), 'page');
  assert.equal(await page.getByRole('link', { name: 'لوحة الإدارة', exact: true }).getAttribute('aria-current'), null);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(100);
  await go('/admin/catalog/products');
  await page.getByRole('button', { name: 'تعديل قميص قطني بألوان متعددة' }).waitFor();
  await overflow('Mobile products');
  await page.screenshot({ path: `${directory}/mobile.png`, fullPage: true });
  const opener = page.getByRole('button', { name: 'فتح القائمة', exact: true });
  await opener.click();
  const drawer = page.locator('dialog');
  assert.equal(await drawer.evaluate(node => node.open), true);
  assert.equal(await page.evaluate(() => document.body.style.overflow), 'hidden');
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.querySelector('main').contains(document.activeElement)), false);
  }
  await page.screenshot({ path: `${directory}/mobile-drawer.png` });
  await page.keyboard.press('Escape');
  assert.equal(await drawer.evaluate(node => node.open), false);
  assert.equal(await opener.evaluate(node => node === document.activeElement), true);
  assert.equal(await page.evaluate(() => document.body.style.overflow), '');
  await opener.click(); await drawer.getByRole('link', { name: 'المنتجات', exact: true }).click();
  assert.equal(await drawer.evaluate(node => node.open), false);
  await opener.click(); await drawer.getByRole('link', { name: 'التصنيفات', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: 'تصنيفات المنتجات' }).waitFor();
  assert.equal(await drawer.evaluate(node => node.open), false);
  await opener.click(); await page.getByRole('button', { name: 'إغلاق القائمة' }).click();
  assert.equal(await opener.evaluate(node => node === document.activeElement), true);
  await opener.click(); await page.mouse.click(8, 400);
  assert.equal(await drawer.evaluate(node => node.open), false);
  await opener.click(); await page.setViewportSize({ width: 1280, height: 900 });
  await page.waitForFunction(() => !document.querySelector('dialog').open);
  assert.equal(await drawer.evaluate(node => node.open), false);
  assert.equal(await page.getByRole('button', { name: 'طي القائمة', exact: true }).evaluate(node => node === document.activeElement), true);
  await page.getByRole('link', { name: 'المنتجات', exact: true }).focus();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForFunction(() => document.activeElement?.getAttribute('aria-controls') === 'admin-mobile-menu');
  assert.equal(await opener.evaluate(node => node === document.activeElement), true);
  checks.push('Mobile native modal: Tab containment/background inert, Escape and close/backdrop restore opener focus, same/different route closes, desktop resize restores visible focus');
  await page.setViewportSize({ width: 320, height: 800 });
  for (const path of ['/admin', '/admin/catalog/products', '/admin/catalog/categories', '/admin/settings', '/admin/settings?tab=shipping', '/admin/security']) {
    await go(path); await page.waitForTimeout(250); await overflow(`320px ${path}`);
  }
  await go('/admin/settings?tab=shipping');
  const table = page.getByRole('region', { name: /طرق الشحن/ });
  await table.waitFor(); await table.focus();
  assert.equal(await table.evaluate(node => node === document.activeElement), true);
  assert.ok(await table.evaluate(node => node.scrollWidth > node.clientWidth));
  checks.push('Shipping table scrolls locally and can receive keyboard focus');
  await page.getByTestId('add-zone-button').click();
  await page.getByTestId('zone-name-ar-input').fill('منطقة تجريبية');
  await page.getByTestId('zone-name-en-input').fill('Test zone');
  await page.getByTestId('gov-checkbox-alexandria').check();
  await page.getByTestId('submit-zone-button').click();
  await page.getByRole('status').filter({ hasText: 'تمت إضافة منطقة الشحن بنجاح.' }).waitFor();
  assert.equal(mutations.find(row => row.path.endsWith('/shipping/zones')).headers['x-csrf-token'], csrf);
  checks.push('Shipping add-zone modal usable at 320px; fixture save and CSRF preserved');
  await go('/admin/catalog/categories');
  await page.getByRole('button', { name: /إضافة تصنيف رئيسي/ }).click();
  await page.locator('#cat-name').fill('تصنيف تجريبي');
  await page.locator('#cat-slug').fill('browser-category');
  await page.getByRole('button', { name: 'إضافة التصنيف', exact: true }).click();
  await page.getByText('تم إنشاء التصنيف بنجاح').waitFor();
  assert.equal(mutations.find(row => row.path.endsWith('/categories')).headers['x-csrf-token'], csrf);
  checks.push('Category create modal usable at 320px; fixture save and CSRF preserved');
  categories = [category];
  await go('/admin/catalog/products');
  await page.getByRole('button', { name: 'منتج جديد', exact: true }).click();
  await page.getByLabel('اسم المنتج', { exact: true }).fill('مسودة اختبار المتصفح');
  await page.getByLabel('ملابس', { exact: true }).check();
  await page.getByLabel('SKU 1', { exact: true }).fill('UI-BROWSER');
  await page.getByLabel('السعر 1', { exact: true }).fill('0.001');
  await page.getByRole('button', { name: 'حفظ المسودة', exact: true }).click();
  await page.getByText('صحح الأسعار المشار إليها.').waitFor();
  assert.equal(await page.getByLabel('SKU 1', { exact: true }).inputValue(), 'UI-BROWSER');
  await page.getByLabel('السعر 1', { exact: true }).fill('0.29');
  await page.getByRole('button', { name: 'حفظ المسودة', exact: true }).click();
  await page.getByText('تم حفظ المسودة بنجاح.').waitFor();
  const save = mutations.find(row => row.path.endsWith('/products'));
  assert.equal(save.headers['x-csrf-token'], csrf); assert.equal(save.headers['x-pricing-revision'], 'EGP:2'); assert.ok(save.headers['idempotency-key']);
  assert.equal(save.body.variants[0].priceMinor, '29');
  checks.push('Product validation preserves inputs; successful fixture save retains CSRF/pricing/idempotency headers and minor-unit price');
  await go('/admin/settings');
  await page.locator('#store_name').fill('متجر اختبار المتصفح');
  await page.getByRole('button', { name: 'حفظ التغييرات', exact: true }).click();
  await page.getByText('تم حفظ إعدادات المتجر بنجاح.').waitFor();
  assert.equal(mutations.find(row => row.path.endsWith('/profile')).headers['x-csrf-token'], csrf);
  checks.push('Profile form fixture save and CSRF preserved');
  await go('/admin?role=support'); await opener.click();
  assert.equal(await drawer.getByRole('link').count(), 2);
  assert.equal(await drawer.getByRole('link', { name: 'المنتجات' }).count(), 0);
  await page.keyboard.press('Escape');
  checks.push('Support navigation displays only dashboard and account security (UI role fixture, not API authorization proof)');
  failed = '/catalog/products'; await go('/admin/catalog/products'); await page.getByRole('alert').waitFor();
  assert.equal(await page.getByLabel('اسم المنتج', { exact: true }).count(), 0);
  failed = ''; products = []; await go('/admin/catalog/products'); await page.getByText('لا توجد مسودات بعد.').waitFor();
  checks.push('Initial product load error and empty collection shown clearly');
  for (const [endpoint, path, empty] of [['/catalog/categories', '/admin/catalog/categories', 'لا توجد تصنيفات'], ['/settings/shipping', '/admin/settings?tab=shipping', 'لا توجد مناطق شحن مهيأة']]) {
    failed = endpoint; await go(path); await page.getByRole('alert').waitFor();
    await page.getByText('تعذر تحميل البيانات. أعد تحميل الصفحة للمحاولة مجددًا.').waitFor();
    assert.equal(await page.getByText(empty).count(), 0);
  }
  checks.push('Category/shipping initial load errors do not display empty success invitations');
  failed = ''; await page.setViewportSize({ width: 1280, height: 350 }); await go('/admin');
  await page.getByRole('button', { name: 'طي القائمة', exact: true }).click();
  const rail = page.locator('.admin-sidebar');
  assert.ok(await rail.evaluate(node => node.scrollHeight > node.clientHeight));
  await page.keyboard.press('Tab');
  await page.getByRole('link', { name: 'المنتجات', exact: true }).focus();
  assert.ok(await rail.evaluate(node => node.scrollTop > 0));
  assert.equal(await page.locator('.admin-sidebar .admin-nav-link[aria-label="المنتجات"] .admin-tooltip').isVisible(), true);
  checks.push('Collapsed short desktop rail remains scrollable with visible keyboard tooltip');
  assert.deepEqual(errors, []);
  await writeFile(`${directory}/browser-results.json`, JSON.stringify({ environment: 'Headless Microsoft Edge; actual components in isolated Vite harness; mocked API data and Next client navigation adapter; no live login or database writes', checks, errors }, null, 2));
  console.log(JSON.stringify({ checks, errors }, null, 2));
} catch(error) { console.log(JSON.stringify({ errors, url: page.url(), body: (await page.locator('body').innerText()).slice(0, 4500) }, null, 2)); throw error; } finally { await context.close(); await browser.close(); }
