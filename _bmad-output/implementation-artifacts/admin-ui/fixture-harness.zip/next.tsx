import React, { useSyncExternalStore } from 'react';
function subscribe(callback: () => void) { window.addEventListener('popstate', callback); return () => window.removeEventListener('popstate', callback); }
export function usePathname() { return useSyncExternalStore(subscribe, () => location.pathname); }
export function useRouter() { return { replace: navigate, refresh() {} }; }
export function navigate(href: string) { history.pushState(null, '', href); window.dispatchEvent(new PopStateEvent('popstate')); }
export default function Link({ href, onClick, onNavigate, children, ...props }: any) { return <a {...props} href={href} onClick={event => { onClick?.(event); if (!event.defaultPrevented && !event.ctrlKey && !event.metaKey) { event.preventDefault(); onNavigate?.(event); navigate(href); } }}>{children}</a>; }
